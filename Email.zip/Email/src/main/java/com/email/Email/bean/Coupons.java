package com.email.Email.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Coupons {

	@Id
	private String coupon;
	
	private String promos;

	public String getCoupon() {
		return coupon;
	}

	public void setCoupon(String coupon) {
		this.coupon = coupon;
	}

	public String getPromos() {
		return promos;
	}

	public void setPromos(String promos) {
		this.promos = promos;
	}

	public Coupons(String coupon, String promos) {
		super();
		this.coupon = coupon;
		this.promos = promos;
	}

	public Coupons() {
		super();
	}

	@Override
	public String toString() {
		return "Coupons [coupon=" + coupon + ", promos=" + promos + "]";
	}
	
	
	
}
