package com.email.Email.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.email.Email.bean.Coupons;
import com.email.Email.bean.Customer;
import com.email.Email.repo.CouponRepo;
import com.email.Email.service.NotificationService;



@RestController
public class EmailController {

	@Autowired
	private NotificationService notificationService;

	@Autowired
	private CouponRepo crepo;
	
	@RequestMapping("/sendmail")
	public String signupsuccess(@RequestParam String c_id)
	{
		Optional<Customer> customer =
		notificationService.getCustomer(Integer.parseInt(c_id));
		
		System.out.println(customer);
		System.out.println(customer.get().getEmail());
		try
		{
			notificationService.Notification(customer);
		}
		catch(MailException e)
		{
			System.out.println(e.getMessage());
		}
		return "Email has been sent";
	}
}
